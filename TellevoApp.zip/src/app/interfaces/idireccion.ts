export interface IDireccion {
    strDireccion: string;
    strNumero: string;
}
